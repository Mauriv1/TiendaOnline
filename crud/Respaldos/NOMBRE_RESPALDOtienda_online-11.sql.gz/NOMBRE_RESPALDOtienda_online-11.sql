CREATE DATABASE IF NOT EXISTS tienda_online;

USE `tienda_online`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `cliente`;

CREATE TABLE `cliente` (
  `id_cliente` int(4) NOT NULL AUTO_INCREMENT,
  `id_direccion` int(4) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido_paterno` varchar(15) NOT NULL,
  `apellido_materno` varchar(15) NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `cliente` VALUES (1,1,"Shoshanna","Forri","Dodworth"),
(2,2,"Briant","Kneath","Chmiel"),
(3,3,"Adele","Staniforth","Roberto"),
(4,4,"Micheil","Potier","Cudde"),
(5,5,"James","Schaben","Pennuzzi");


DROP TABLE IF EXISTS `compra`;

CREATE TABLE `compra` (
  `id_compra` int(4) NOT NULL AUTO_INCREMENT,
  `estatus_compra` enum('proceso','cancelado','terminado') NOT NULL,
  `total_compra` float NOT NULL,
  PRIMARY KEY (`id_compra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `detalle_compra`;

CREATE TABLE `detalle_compra` (
  `id_compra` int(4) NOT NULL AUTO_INCREMENT,
  `id_producto` int(4) NOT NULL,
  `cantidad` int(3) NOT NULL,
  `fecha_compra` date NOT NULL,
  `total_compra` float NOT NULL,
  PRIMARY KEY (`id_compra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `detalle_venta`;

CREATE TABLE `detalle_venta` (
  `id_venta` int(4) NOT NULL AUTO_INCREMENT,
  `id_producto` int(4) NOT NULL,
  `cantidad` int(3) NOT NULL,
  `fecha_venta` date NOT NULL,
  `total_venta` float NOT NULL,
  PRIMARY KEY (`id_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `direccion`;

CREATE TABLE `direccion` (
  `id_direccion` int(4) NOT NULL AUTO_INCREMENT,
  `calle` varchar(15) DEFAULT NULL,
  `numero` int(4) DEFAULT NULL,
  `colonia` varchar(30) DEFAULT NULL,
  `ciudad` varchar(30) DEFAULT NULL,
  `estado` varchar(15) DEFAULT NULL,
  `pais` varchar(15) DEFAULT NULL,
  `telefono` varchar(15) NOT NULL,
  `email` varchar(15) NOT NULL,
  PRIMARY KEY (`id_direccion`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `direccion` VALUES (1,"Upham",587,"Eagle Crest","New Orleans","Louisiana","United States","776 879 3258","icartmel0@mit.e"),
(2,"Fisk",353,"Mandrake","Fort Wayne","Indiana","United States","776 666 9499","rsancias1@twitt"),
(3,"Hoepker",657,"Forster","El Paso","Texas","United States","777 574 1390","styler2@netscap"),
(4,"Kenwood",521,"Golf","Amarillo","Texas","United States","773 289 8211","gkeaton3@phpbb."),
(5,"Westend",528,"Fairview","Columbia","South Carolina","United States","777 590 0273","amckee4@imdb.co"),
(6,"Village Green",745,"Rigney","Tuscaloosa","Alabama","United States","779 859 9771","wmallall5@jooml"),
(7,"Lillian",204,"Shasta","Philadelphia","Pennsylvania","United States","777 756 0193","msholl6@youtube"),
(8,"Eagle Crest",90,"Westridge","Portland","Oregon","United States","779 671 3095","dbrason7@senate"),
(9,"Center",49,"Moulton","Fort Lauderdale","Florida","United States","775 367 3680","hedmonston8@col"),
(10,"Derek",457,"Glendale","Oakland","California","United States","777 629 8610","npurselowe9@del");


DROP TABLE IF EXISTS `marca`;

CREATE TABLE `marca` (
  `id_marca` int(2) NOT NULL AUTO_INCREMENT,
  `id_proveedor` int(2) NOT NULL,
  `marca` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `marca` VALUES (1,1,"Stemline Therap"),
(2,2,"Allstate Corpor"),
(3,3,"Goldman Sachs M"),
(4,4,"iShares MSCI Ne"),
(5,5,"Cimpress N.V"),
(6,6,"Nuveen Real Est"),
(7,7,"PhaseRx, Inc."),
(8,8,"Lexington Realt"),
(9,9,"Kaman Corporati"),
(10,10,"Xencor, Inc.");


DROP TABLE IF EXISTS `producto`;

CREATE TABLE `producto` (
  `id_producto` int(4) NOT NULL AUTO_INCREMENT,
  `id_marca` int(2) NOT NULL,
  `id_proveedor` int(2) NOT NULL,
  `modelo` varchar(15) NOT NULL,
  `nom_producto` varchar(25) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `caracteristicas` varchar(120) NOT NULL,
  `precio_prov` float NOT NULL,
  `precio_pub` float NOT NULL,
  `fecha` date NOT NULL,
  `stock` int(3) NOT NULL,
  PRIMARY KEY (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `producto` VALUES (1,0,0,"SOP-3110","TRIPIE PARA CELULAR","auctor elit sed vulputate mi","nulla facilisi nullam vehicula ipsum a arcu cursus vitae congue",55,110,"2022-03-06",5),
(2,3,7,"DY-01","CARGADOR UNIVERSAL PARA L","nulla facilisi nullam vehicula ipsum a arcu cursus","auctor elit sed vulputate mi",65,130,"2022-03-06",3),
(3,8,2,"WS-887","BOCINA DISEÑO","auctor elit sed vulputate mi","nulla facilisi nullam vehicula ipsum a arcu cursus vitae congue",120,240,"2022-03-06",1),
(4,1,10,"BAS10","BASCULA","nulla facilisi nullam vehicula ipsum a arcu cursus","auctor elit sed vulputate mi","175.5",351,"2022-03-06",1),
(5,0,0,"B05","AUDIFONOS DIADEMA","auctor elit sed vulputate mi","nulla facilisi nullam vehicula ipsum a arcu cursus vitae congue",0,234,"2022-03-06",5),
(6,0,0,008,"LINTERNA DE MANO","nulla facilisi nullam vehicula ipsum a arcu cursus","auctor elit sed vulputate mi",52,104,"2022-03-06",3),
(7,0,0,"MB-107","BOCINA BARRA SONIDO","auctor elit sed vulputate mi","nulla facilisi nullam vehicula ipsum a arcu cursus vitae congue","217.5",435,"2022-03-06",1),
(8,0,0,"FS-003","VENTILADOR PORTATIL RECAR","nulla facilisi nullam vehicula ipsum a arcu cursus","auctor elit sed vulputate mi","36.5",73,"2022-03-06",5),
(9,0,0,"SA411T","BOCINA BLUETOOTH 4IN","auctor elit sed vulputate mi","nulla facilisi nullam vehicula ipsum a arcu cursus vitae congue",91,182,"2022-03-06",2),
(10,0,0,"950BT","AUDIFONOS WIRELESS","nulla facilisi nullam vehicula ipsum a arcu cursus","auctor elit sed vulputate mi","201.5",403,"2022-03-06",5),
(11,0,0,"AIRPODS 2DA","AIRPODS 2DA GEN","auctor elit sed vulputate mi","nulla facilisi nullam vehicula ipsum a arcu cursus vitae congue",260,520,"2022-03-06",5),
(12,0,2,"","","","",0,0,"0000-00-00",0);


DROP TABLE IF EXISTS `proveedor`;

CREATE TABLE `proveedor` (
  `id_proveedor` int(2) NOT NULL AUTO_INCREMENT,
  `proveedor` varchar(30) NOT NULL,
  `banco` varchar(30) NOT NULL,
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `proveedor` VALUES (1,"Y-Solowarm","diners-club-enroute"),
(2,"Greenlam","switch"),
(3,"Alpha","jcb"),
(4,"Otcom","instapayment"),
(5,"Sonsing","mastercard"),
(6,"Transcof","maestro"),
(7,"Holdlamis","mastercard"),
(8,"Fintone","instapayment"),
(9,"Voyatouch","laser"),
(10,"Solarbreeze","jcb");


DROP TABLE IF EXISTS `venta`;

CREATE TABLE `venta` (
  `id_venta` int(4) NOT NULL AUTO_INCREMENT,
  `estatus_venta` enum('proceso','cancelado','terminado') NOT NULL,
  `total_venta` float NOT NULL,
  PRIMARY KEY (`id_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `viewconsulta`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewconsulta` AS select `p`.`modelo` AS `modelo`,`p`.`nom_producto` AS `nom_producto`,`m`.`marca` AS `marca`,`pr`.`proveedor` AS `proveedor` from ((`producto` `p` join `marca` `m` on((`p`.`id_marca` = `m`.`id_marca`))) join `proveedor` `pr` on((`p`.`id_proveedor` = `pr`.`id_proveedor`)));

INSERT INTO `viewconsulta` VALUES ("DY-01","CARGADOR UNIVERSAL PARA L","Goldman Sachs M","Holdlamis"),
("WS-887","BOCINA DISEÑO","Lexington Realt","Greenlam"),
("BAS10","BASCULA","Stemline Therap","Solarbreeze");


SET foreign_key_checks = 1;
